 <?php $__env->startSection('content'); ?>
<div class="w-50 mx-auto border p-5">
    <form action="<?php echo e(route('SEARCH::ACTION')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <h3 class="mb-2">Operator Name</h3>
        <div
            class="w-100 d-flex justify-content-between gap-3 align-items-center"
        >
            <div class="w-50">
                <select class="js-example-basic-single w-100" name="operator">
                    <?php $__currentLoopData = $operators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($operator->id); ?>">
                        <?php echo e($operator->name); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="w-50 d-flex align-items-center gap-2">
                <input name="from" type="date" class="form-control" />
                <p>to</p>
                <input name="to" type="date" class="form-control" />
            </div>
        </div>
        <div class="d-flex justify-content-center mt-3">
            <button type="submit" class="btn btn-info text-white">
                Search
            </button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel\daily_report\resources\views/search.blade.php ENDPATH**/ ?>