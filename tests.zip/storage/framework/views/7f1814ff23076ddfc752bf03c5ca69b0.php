 <?php $__env->startSection('content'); ?>
<div class="w-50 mx-auto p-5 border">
    <div class="mt-5">
        <div class="mt-5">
            <div>
                <h2 class="text-center mb-2">Reports</h2>
                <div class="d-flex justify-content-center w-50 mx-auto gap-3">
                    <p><?php echo e($from); ?></p>
                    <p>to</p>
                    <p><?php echo e($to); ?></p>
                </div>
            </div>
            <?php if(!empty($reports)): ?>
            <div class="mt-3">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Name</th>
                            <th scope="col">date</th>
                            <th scope="col">
                                <div class="d-flex justify-content-end">
                                    Action
                                </div>
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($key + 1); ?></th>
                            <td><?php echo e($report->createBy($report->user_id)); ?></td>
                            <td>
                                <?php echo e($report->created_at->format('j F, Y')); ?>

                            </td>
                            <td>
                                <div class="d-flex justify-content-end">
                                    <a
                                        href="<?php echo e(route('REPORT_ITEM::CREATE::VIEW',$report->id)); ?>"
                                        class="btn btn-sm btn-info text-white"
                                        href=""
                                        >View</a
                                    >
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel\daily_report\resources\views/results.blade.php ENDPATH**/ ?>