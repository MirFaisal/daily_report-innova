 <?php $__env->startSection('PageTitle'); ?> <?php echo e($user->name); ?> Reports from
<?php echo e($from); ?> to <?php echo e($to); ?>

<?php $__env->stopSection(); ?> <?php $__env->startSection('content'); ?>
<div class="w-50 mx-auto p-5 border">
    <div class="mt-5">
        <div class="mt-5">
            <div>
                <h2 class="text-center mb-2"><?php echo e($user->name); ?> Reports</h2>
                <div class="d-flex justify-content-center w-50 mx-auto gap-3">
                    <h4><?php echo e($from); ?></h4>
                    <p>to</p>
                    <h4><?php echo e($to); ?></h4>
                </div>
            </div>
            <?php if(!empty($reports)): ?> <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $carbonDate = \Carbon\Carbon::parse($report->report_date); ?>
            <div
                class="mt-3 mb-3"
                style="border: 1px solid rgb(199, 199, 199); padding: 15px"
            >
                <h3 class="mb-3">
                    <i
                        ><?php echo e($carbonDate->format('l')); ?> -
                        <?php echo e($carbonDate->format('M d, Y')); ?>

                    </i>
                </h3>
                <?php $__currentLoopData = $report->reportItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $reportItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h5 style="margin-left: 20px">
                    <?php echo e($key + 1); ?>. <?php echo e($reportItem->content); ?>

                </h5>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel\daily_report\resources\views/results.blade.php ENDPATH**/ ?>