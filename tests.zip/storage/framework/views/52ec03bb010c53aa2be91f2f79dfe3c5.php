 <?php $__env->startSection('content'); ?>
<div class="w-50 mx-auto border p-5">
    <h3>REPORT</h3>
    <div class="mt-5" style="font-size: 20px">
        <p><b>Date:</b> <?php echo e($reportDate->format('M d, Y')); ?></p>
        <p><b>Name:</b> <?php echo e($report->user->name); ?></p>
    </div>
    <div class="mt-5" style="font-size: 20px">
        <h4>Tasks</h4>
        <table class="table mt-4">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Task</th>
                    <?php if($editable): ?>
                    <th scope="col">Action</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php if($editable): ?>
                <tr>
                    <form
                        action="<?php echo e(route('REPORT_ITEM::CREATE::ACTION')); ?>"
                        method="POST"
                    >
                        <?php echo csrf_field(); ?>
                        <input
                            type="hidden"
                            name="report_date_id"
                            value="<?php echo e($report->id); ?>"
                        />
                        <input
                            type="hidden"
                            name="user_id"
                            value="<?php echo e($report->user_id); ?>"
                        />
                        <th scope="row">#</th>
                        <td>
                            <input
                                type="text"
                                name="content"
                                class="form-control"
                            />
                        </td>
                        <td>
                            <button class="btn btn-success">+</button>
                        </td>
                    </form>
                </tr>
                <?php $totalReportItems = count($reportItems); ?>
                <?php endif; ?> <?php $__currentLoopData = $reportItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $reportItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($totalReportItems - $key); ?></th>
                    <td><?php echo e($reportItem->content); ?></td>
                    <?php if($editable): ?>
                    <td>
                        <a
                            class="btn btn-danger"
                            href="<?php echo e(route('REPORT_ITEM::DELETE::ACTION', $reportItem->id)); ?>"
                            >-</a
                        >
                    </td>
                    <?php endif; ?>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel\daily_report\resources\views/show-all-items.blade.php ENDPATH**/ ?>