<?php $userName = auth()->user()->name; ?> <?php $__env->startSection('PageTitle'); ?>
<?php echo e(auth()->user()->user_type == 'Admin' ? 'All Reports' : "$userName's Daily Reports..."); ?>

<?php $__env->stopSection(); ?> <?php $__env->startSection('content'); ?>
<div class="w-50 mx-auto p-5 border">
    <div class="d-flex pb-2 justify-content-between border-bottom">
        <h3>
            <?php $userName = auth()->user()->name; ?>
            <?php echo e(auth()->user()->user_type == 'Admin' ? 'All Reports' : "$userName's Daily Reports..."); ?>

        </h3>
        <a class="btn btn-primary" href="<?php echo e(route('REPORT::CREATE::VIEW')); ?>">
            <?php $today =  \Carbon\Carbon::now()->format('M d, Y') ?>
            <?php echo e(auth()->user()->user_type == 'Admin' ? 'Make Report for Someone' : "Make Report $today"); ?>

        </a>
    </div>
    <div class="mt-5">
        <div class="mt-5">
            <?php if(!empty($currentUserReportDate) || !empty($reportDate)): ?>

            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Date</th>
                        <th scope="col">
                            <div class="d-flex justify-content-end">Action</div>
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(Auth()->user()->user_type == 'Admin'): ?>
                    <?php $__currentLoopData = $reportDate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $carbonDate = \Carbon\Carbon::parse($report->report_date);
                    ?>
                    <tr>
                        <th scope="row"><?php echo e($key + 1); ?></th>
                        <td>
                            <?php echo e($carbonDate->format('l')); ?> -
                            <?php echo e($carbonDate->format('M d, Y')); ?>

                        </td>
                        <td>
                            <div class="d-flex justify-content-end">
                                <a
                                    href="<?php echo e(route('REPORT_ITEM::CREATE::VIEW',$report->id)); ?>"
                                    class="btn btn-sm btn-info text-white"
                                    href=""
                                    >View</a
                                >
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div></div>
                    <?php else: ?> <?php $__currentLoopData = $currentUserReportDate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $carbonDate = \Carbon\Carbon::parse($report->report_date);
                    ?>
                    <tr>
                        <th scope="row"><?php echo e($key + 1); ?></th>
                        <td>
                            <?php echo e($carbonDate->format('l')); ?> -
                            <?php echo e($carbonDate->format('M d, Y')); ?>

                        </td>
                        <td>
                            <div class="d-flex justify-content-end">
                                <a
                                    href="<?php echo e(route('REPORT_ITEM::CREATE::VIEW',$report->id)); ?>"
                                    class="btn btn-sm btn-info text-white"
                                    href=""
                                    >View</a
                                >
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php endif; ?>
                </tbody>
            </table>
            <?php echo e($reportDate->links()); ?>

            <?php else: ?>
            <div class="alert alert-warning" role="alert">No report added.</div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel\daily_report\resources\views/welcome.blade.php ENDPATH**/ ?>