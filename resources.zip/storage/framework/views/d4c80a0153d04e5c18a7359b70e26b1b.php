 <?php $__env->startSection('content'); ?>
<?php $showToday =  \Carbon\Carbon::now()->format('M d, Y') ?>
<div class="w-50 mx-auto p-5 border">
    <?php if(Session::has('error')): ?>
    <div class="alert alert-danger" role="alert">
        <?php echo e(Session::get("error")); ?>

    </div>
    <?php endif; ?>
    <form action="<?php echo e(route('REPORT::CREATE::ACTION')); ?>" method="post">
        <?php echo csrf_field(); ?> <?php if(auth()->user()->user_type == 'Admin'): ?>
        <div class="mt-2">
            <h3>Select Date</h3>
            <input type="date" name="ADM_REPORT_DATE" class="form-control" />
        </div>
        <div class="mt-4">
            <h3>Select Member</h3>
            <select name="ADM_USER_ID" class="form-select">
                <option value="NO_USER">User List</option>
                <?php $__currentLoopData = $operators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($operator->id); ?>"><?php echo e($operator->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <?php else: ?>
        <div>
            <h3><?php echo e($showToday); ?></h3>
        </div>
        <?php endif; ?>
        <div class="d-flex justify-content-end mt-4">
            <button class="btn btn-primary mt-3" type="submit">Initiate</button>
        </div>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel\daily_report\resources\views/create-report.blade.php ENDPATH**/ ?>